/**
 * noise-glitch-visualizer.js
 *
 * Fallback audio visualizer (glitch art canvas) yang muncul saat lirik tidak tersedia.
 * Terinspirasi dari CodePen "Noise Making Noise" oleh DrewDahlman.
 * Menggunakan analyser Web Audio API yang sudah ada di audio-pool.js.
 * Kalau analyser tidak tersedia (server-side playback), jalan dalam mode
 * fake-beat (animasi looping tanpa data frekuensi nyata).
 */

import { store } from "../store.js";
import { analyser, dataArray } from "./playback-sync.js";

// ── State ──────────────────────────────────────────────────────────────────
let _canvas = null;
let _ctx = null;
let _rafId = null;
let _frameCount = 0;
let _fakePhase = 0;   // untuk mode tanpa analyser
let _active = false;

// ── Helpers ────────────────────────────────────────────────────────────────

/**
 * Salin kotak acak dari kanvas ke posisi lain (glitch tipe 1).
 */
function _drawBoxGlitch(ctx, canvas) {
    let rx = Math.random() * canvas.width;
    let ry = Math.random() * canvas.height;
    const rw = 10 + Math.random() * 40;
    const rh = 10 + Math.random() * 40;
    const dx = Math.random() * canvas.width;
    const dy = Math.random() * canvas.height;
    if (rx + rw > canvas.width)  rx = canvas.width  - rw;
    if (ry + rh > canvas.height) ry = canvas.height - ry;
    try {
        const img = ctx.getImageData(rx, ry, rw, rh);
        ctx.putImageData(img, dx, dy);
    } catch (_) { /* ignore cross-origin errors */ }
}

/**
 * Salin kotak acak yang sedikit lebih besar, geser dekat sumber (glitch tipe 2).
 */
function _drawBoxGlitch2(ctx, canvas) {
    let rx = Math.random() * canvas.width;
    let ry = Math.random() * canvas.height;
    const rw = 20 + Math.random() * 60;
    const rh = 20 + Math.random() * 60;
    const dx = rx - 30 + Math.random() * 60;
    const dy = ry - 30 + Math.random() * 60;
    if (rx + rw > canvas.width)  rx = canvas.width  - rw;
    if (ry + rh > canvas.height) ry = canvas.height - ry;
    try {
        const img = ctx.getImageData(rx, ry, rw, rh);
        ctx.putImageData(img, dx, dy);
    } catch (_) { /* ignore */ }
}

/**
 * Geser channel R/G/B secara independen (chromatic aberration glitch).
 */
function _drawRGBGlitch(ctx, canvas, rOff, gOff, bOff) {
    try {
        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const arr = new Uint8ClampedArray(imgData.data);
        for (let i = 0; i < arr.length; i += 4) {
            const ri = i + rOff * 4;
            const gi = i + gOff * 4 + 1;
            const bi = i + bOff * 4 + 2;
            if (ri >= 0 && ri < arr.length)     arr[ri]     = imgData.data[i];
            if (gi >= 0 && gi < arr.length - 1) arr[gi]     = imgData.data[i + 1];
            if (bi >= 0 && bi < arr.length - 2) arr[bi]     = imgData.data[i + 2];
        }
        ctx.putImageData(new ImageData(arr, imgData.width, imgData.height), 0, 0);
    } catch (_) { /* ignore */ }
}

/**
 * Gambar satu baris glitch dengan pergeseran RGB (scan-line distortion).
 */
function _createGlitchLine(ctx, canvas, x, y, fbc) {
    const shift = Math.round((fbc || 0) / 20);
    try {
        const w = Math.floor(canvas.width * 0.8);
        if (w <= 0) return;
        const imgData = ctx.getImageData(x, y, w, 1);
        const arr = new Uint8ClampedArray(imgData.data);
        const rOff = -shift, gOff = shift, bOff = shift * 2;
        for (let i = 0; i < arr.length; i += 4) {
            const ri = i + rOff * 4;
            const gi = i + gOff * 4 + 1;
            const bi = i + bOff * 4 + 2;
            if (ri >= 0 && ri < arr.length)     arr[ri]     = imgData.data[i];
            if (gi >= 0 && gi < arr.length - 1) arr[gi]     = imgData.data[i + 1];
            if (bi >= 0 && bi < arr.length - 2) arr[bi]     = imgData.data[i + 2];
        }
        ctx.putImageData(new ImageData(arr, imgData.width, 1), x, y);
    } catch (_) { /* ignore */ }
}

/**
 * Gambar latar background: noise warna-warni + gradient overlay
 * agar tiap frame memiliki dasar yang berbeda.
 */
function _drawBackground(ctx, canvas, levelAvg) {
    // Semi-transparent overlay untuk fade efek sebelumnya
    const alpha = 0.08 + (levelAvg / 255) * 0.12;
    ctx.fillStyle = `rgba(0,0,0,${alpha.toFixed(3)})`;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Gambar beberapa titik noise berwarna
    const noiseCount = 3 + Math.floor((levelAvg / 255) * 12);
    for (let n = 0; n < noiseCount; n++) {
        const nx = Math.random() * canvas.width;
        const ny = Math.random() * canvas.height;
        const nr = 1 + Math.random() * (1 + levelAvg / 80);
        const hue = (Date.now() / 30 + n * 47) % 360;
        const sat = 60 + Math.random() * 40;
        const lit = 40 + Math.random() * 40;
        ctx.beginPath();
        ctx.arc(nx, ny, nr, 0, Math.PI * 2);
        ctx.fillStyle = `hsl(${hue},${sat}%,${lit}%)`;
        ctx.fill();
    }
}

// ── Fake-beat helper (saat analyser tidak tersedia) ────────────────────────

function _getFakeLevelAvg() {
    // Buat pola "beat" sederhana berdasarkan waktu
    _fakePhase += 0.04;
    const base = 40 + Math.sin(_fakePhase * 1.3) * 25 + Math.sin(_fakePhase * 2.7) * 15;
    const spike = Math.random() < 0.04 ? Math.random() * 60 : 0; // kadang ada spike
    return Math.max(0, Math.min(255, base + spike));
}

// ── Main frame loop ────────────────────────────────────────────────────────

function _frame() {
    if (!_active || !_canvas || !_ctx) return;

    const canvas = _canvas;
    const ctx    = _ctx;
    _frameCount++;

    // Ambil data frekuensi
    let fbc = null;
    let levelAvg = 0;

    if (analyser && dataArray) {
        analyser.getByteFrequencyData(dataArray);
        fbc = dataArray;
        const barCount = Math.floor(canvas.height / 2);
        for (let i = 0; i < barCount; i++) levelAvg += fbc[i];
        levelAvg /= barCount;
    } else {
        // Fallback: fake level
        levelAvg = _getFakeLevelAvg();
    }

    // Gambar background dengan noise
    _drawBackground(ctx, canvas, levelAvg);

    // Hitung intensitas efek
    const boxCount   = Math.max(1, Math.ceil((levelAvg / 110) ** (levelAvg / 110)));
    const glitchCount = Math.max(1, Math.ceil((levelAvg / 70)  ** (levelAvg / 70)));

    // RGB chromatic aberration
    const randR = Math.round(-glitchCount + Math.random() * glitchCount * 2);
    const randG = Math.round(-glitchCount + Math.random() * glitchCount * 2);
    const randB = Math.round(-glitchCount + Math.random() * glitchCount * 2);
    _drawRGBGlitch(ctx, canvas, randR, randG, randB);

    // Box glitches berdasar level audio
    for (let a = 0; a < boxCount; a++) {
        if (Math.random() * 100 + levelAvg > 220) {
            _drawBoxGlitch2(ctx, canvas);
        }
    }

    // Scan-line glitch
    const barCount = Math.floor(canvas.height / 2);
    for (let i = 0; i < barCount; i++) {
        if (Math.random() * 150 + levelAvg > 300) {
            const fbcVal = fbc ? fbc[i] : (levelAvg + Math.random() * 30);
            _createGlitchLine(ctx, canvas, canvas.width * 0.1, i * 2, fbcVal);
        }
    }

    _rafId = requestAnimationFrame(_frame);
}

// ── Resize helper ──────────────────────────────────────────────────────────

function _resizeCanvas() {
    if (!_canvas) return;
    const holder = _canvas.parentElement;
    if (!holder) return;
    const w = holder.clientWidth;
    const h = holder.clientHeight;
    if (w > 0 && h > 0 && (_canvas.width !== w || _canvas.height !== h)) {
        _canvas.width  = w;
        _canvas.height = h;
    }
}

// ── Public API ─────────────────────────────────────────────────────────────

/**
 * Inisialisasi canvas yang akan digunakan sebagai visualizer glitch.
 * Dipanggil sekali dari lyrics.js saat module dimuat.
 * @param {HTMLCanvasElement} canvasEl
 */
export function initNoiseGlitch(canvasEl) {
    _canvas = canvasEl;
    _ctx    = canvasEl ? canvasEl.getContext("2d") : null;
    if (_canvas) {
        _resizeCanvas();
        window.addEventListener("resize", _resizeCanvas);
    }
}

/**
 * Mulai animasi visualizer glitch (dipanggil saat lirik tidak tersedia + musik main).
 */
export function startNoiseGlitch() {
    if (_active) return;
    _active = true;
    _resizeCanvas();
    if (!_rafId) _rafId = requestAnimationFrame(_frame);
}

/**
 * Hentikan animasi visualizer glitch (dipanggil saat lirik tersedia).
 * Canvas tidak langsung dihapus — hanya animasi yang berhenti.
 */
export function stopNoiseGlitch() {
    _active = false;
    if (_rafId) {
        cancelAnimationFrame(_rafId);
        _rafId = null;
    }
    // Bersihkan canvas agar tidak ada artefak saat lirik muncul lagi
    if (_ctx && _canvas) {
        _ctx.clearRect(0, 0, _canvas.width, _canvas.height);
    }
}
